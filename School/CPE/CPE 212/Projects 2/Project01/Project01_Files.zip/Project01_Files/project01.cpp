#include "project01.hpp"


bool LoadImage(const std::string & imageFile, Image image)
{
    // Implement this function
}

bool Flip(Image image, Direction d)
{
    // Implement this function
}

bool Rotate(Image image, Rotation r)
{
    // Implement this function
}

void Transpose(Image image)
{
    // Implement this function
}
