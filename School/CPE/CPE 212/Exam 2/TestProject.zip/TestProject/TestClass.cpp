#include "TestClass.h"


TestClass::TestClass()
{
	_testString = "Hello CPE212!";
}

std::string TestClass::output() const
{
	return _testString;
}