#pragma once

#include <string>

class TestClass
{
private:
	std::string _testString;
public:
	TestClass();

	std::string output() const;
};

