#include "TestClass.h"
#include <iostream>


int main()
{
	TestClass test;

	std::cout << test.output() << std::endl;


	return 0;
}