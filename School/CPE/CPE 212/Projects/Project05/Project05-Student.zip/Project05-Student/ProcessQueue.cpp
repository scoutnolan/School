#include "ProcessQueue.hpp"

/// TODO
void ProcessQueue::PushProcess(const std::string & output, Priority p)
{

}

/// TODO
void ProcessQueue::ExecuteNextProcess()
{

}

/// TODO
void ProcessQueue::ReheapUpList(int currentIndex)
{

}

/// TODO
void ProcessQueue::ReheapDownList(int currentIndex)
{

}

/// TODO
bool ProcessQueue::IsEmpty() const
{

}