#include <vector>
#include <iostream>
#include <future>

template<typename Sortable>
std::vector<Sortable> Merge(const std::vector<Sortable> & left, const std::vector<Sortable> & right)
{

}


template<typename Sortable>
std::vector<Sortable> MergeSort_Linear(const std::vector<Sortable> &input)
{
    if(input.size() > 1)
    {
        auto left = MergeSort_Linear(std::vector<Sortable>(input.begin(), input.begin() + input.size() / 2));
        auto right = MergeSort_Linear(std::vector<Sortable>(input.begin() + (input.size() / 2), input.end()));
        return Merge(left, right);
    }
    return input;
}

template<typename Sortable>
std::vector<Sortable> MergeSort_Parallel(const std::vector<Sortable> &input, uint32_t Threshold)
{
    if(input.size() > Threshold)
    {
        auto left = std::async(std::launch::async, MergeSort_Parallel<Sortable>, std::vector<Sortable>(input.begin(), input.begin() + input.size() / 2), Threshold);
        auto right = std::async(std::launch::async, MergeSort_Parallel<Sortable>, std::vector<Sortable>(input.begin() + (input.size() / 2), input.end()), Threshold);
        return Merge(left.get(), right.get());
    }
    else if(input.size() > 1)
    {
        auto left = MergeSort_Linear(std::vector<Sortable>(input.begin(), input.begin() + input.size() / 2));
        auto right = MergeSort_Linear(std::vector<Sortable>(input.begin() + (input.size() / 2), input.end()));
        return Merge(left, right);
    }
    return input;
}

