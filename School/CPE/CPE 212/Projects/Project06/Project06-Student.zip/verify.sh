make clean
make test  

./test