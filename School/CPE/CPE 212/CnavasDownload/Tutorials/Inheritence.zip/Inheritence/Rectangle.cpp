#include "Rectangle.hpp"

Rectangle::Rectangle(float l, float w)
{
    // Complete this function, assigning the location, 
    // length and width appropriately.
    length = l;
    width = w;
}

void Rectangle::CalcArea() {
    Shape::SetArea(length * width);
}

void Rectangle::CalcPerimeter() {
    Shape::SetPerimeter((length * 2) + (width * 2));
}

float Rectangle::GetLength() {
    return length;
}

float Rectangle::GetWidth() {
    return width;
}

	