#include "Shape.hpp"

#ifndef RECTANGLE_HPP
#define RECTANGLE_HPP

class Rectangle : public Shape
{

private:
    float length;
    float width;

public:

    Rectangle(float l, float w);

    void CalcArea();
    void CalcPerimeter();

    float GetLength();
    float GetWidth();
};


#endif // RECTANGLE_HPP
