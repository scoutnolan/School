#include "Rectangle.hpp"

#include <iostream>

int main()
{
    Rectangle r(3.0, 4.0);

    if(r.GetLength() != 3.0)
    {
        std::cout << "Length is incorrect" << std::endl;
        return -1;
    }

    if(r.GetWidth() != 4.0)
    {
        std::cout << "Width is incorrect" << std::endl;
        return -1;
    }

    // Calculate Area
    r.CalcArea();
    // Calculate Perimeter
    r.CalcPerimeter();

    if (r.GetArea() != 12.0) {
        std::cout << "Area is incorrect" << std::endl;
        return -1; 
    }

    if (r.GetPerimeter() != 14.0) {
        std::cout << "Perimeter is incorrect" << std::endl;
        return -1; 
    }


    std::cout << "Implementation is correct!" << std::endl;
}