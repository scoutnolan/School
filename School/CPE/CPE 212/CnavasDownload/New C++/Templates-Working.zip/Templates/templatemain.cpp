#include "templateobj.hpp"
#include "templateobj.cpp"


int main()
{
    List<int> list;

    list.Insert(1);
    list.Insert(2);

    list.Print();

    return 0;
}

