#include "templateobj.hpp"


template<typename Type>
List<Type>::List()
{

}


template<typename Type>
List<Type>::~List()
{
    Node<Type> *tmp;

    while(_head != NULL)
    {
        tmp = _head;
        _head = _head->next;
        delete tmp;
    }
}

template<typename Type>
void List<Type>::Insert(const Type & data)
{
    Node<Type> *newNode = new Node<Type>(data);
    _tail->next = newNode;
    _tail = newNode;

}

template<typename Type>
Type List<Type>::front() const
{
    return _head->data;
}

template<typename Type>
Type List<Type>::back() const
{
    return _tail->data;
}
