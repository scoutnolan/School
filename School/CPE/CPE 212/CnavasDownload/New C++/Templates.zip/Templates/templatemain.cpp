#include "templateobj.hpp"


int main()
{
    List<int> list;

    list.Insert(1);
    list.Insert(2);

    return 0;
}

