#include <string>
#include <iostream>

struct Node
{
    int priority;
    std::string data;
    Node* next;

    Node(const std::string& string, int prio)
    {
        priority = prio;
        data = string;
        next = NULL;
    }
};



class Queue
{
private:
    Node* _beginning;
    unsigned int _count;


public:
    Queue();
    ~Queue();

    void Push(const std::string& data, int priority);
    std::string Pop();

    bool IsEmpty() const;
    unsigned int Size() const;
};
