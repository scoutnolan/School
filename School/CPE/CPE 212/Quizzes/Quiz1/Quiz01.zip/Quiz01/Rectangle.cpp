#include "Rectangle.hpp"


Rectangle::Rectangle(float x, float y, float l, float w)
{
    // Complete this function, assigning the location, 
    // length and width appropriately.
}

// Declare and complete the final 3 functions