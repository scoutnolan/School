#include <cstddef>
#include <iostream>
#include "LList.h"

using namespace std;

struct NodeType {
    ItemType value;
    NodeType* nextNode;
};

LList::LList() {
    head = NULL;
}

LList::~LList() {
    ItemType someItem;

    while ( !IsEmpty() ) {
        RemoveFirst(someItem);
    }
}

bool LList::IsEmpty() const {
    return (head == NULL);
}

void LList::Print() const {
    cout << "Printing the list" << endl;
    NodeType* currentNodePtr = head;

    while (currentNodePtr != NULL) {
        cout << currentNodePtr->value << endl;
        currentNodePtr = currentNodePtr->nextNode;
    }
}

void LList::InsertAsFirst(ItemType item) {
    NodeType* tempPtr = new NodeType;

    tempPtr->value = item;
    tempPtr->nextNode = head;
    head = tempPtr;
}

void LList::RemoveFirst(ItemType &item) {
    NodeType* tempPtr = head;
    item = head->value;
    head = head->nextNode;
    delete tempPtr;
}

void LList::Insert(ItemType item) {
    // Create a tempPtr

    // What happens when the head is null? 

    // Looking for the insertion point
        // Check to see if the value of the here

        // Check to see if the value of where you are is less than the item and make sure the next node isn't pointing to NULL
                // Point the next node of the temp to be the next node of the current node
                // Point the next node of the current node to the temp
        // If the next node is NULL you are putting the item on the end 
    // Don't forget to increment where you are
}

void LList::Delete(ItemType item) {
    // How would we get this done? 
}



